import * as React from 'react';
import './admin-shell-2.scss'; // Assuming you have your CSS file here

interface AdminShell2Props { }

const AdminShell2: React.FunctionComponent<AdminShell2Props> = () => {
return (
<div className="admin-shell-2">
{/* Add your components here */}
</div>
);
};

export default AdminShell2;
