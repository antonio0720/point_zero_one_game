module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {}
  },
  preset: 'postcss-flexbugs-fixes',
  postcssOptions: {
    parser: 'postcss-parser'
  }
};
