// ═══════════════════════════════════════════════════════════════════════════
// POINT ZERO ONE — pzo-web/src/game/runtime/useRunLoop.ts
// Sprint 8: Run Loop Hook — Complete Overhaul
// Density6 LLC · Confidential · All Rights Reserved
//
// CHANGES FROM SPRINT 1:
//   ✦ FREEZE GUARD — all mechanics suppressed when freezeTicks > 0
//   ✦ FREEDOM threshold check every tick — fires RUN_COMPLETE on FREEDOM
//   ✦ fireMacroEvent 'bill' now actually drains cash (was FREEZE 0t = noop)
//   ✦ fireCardDraw ML reroute logic fixed — no longer checks FUBAR on an
//     OPPORTUNITY/IPA-only pool (dead code removed, real reroute added)
//   ✦ EMPIRE pulse: bleed evaluation every tick, isolation tax on card plays,
//     bot wave check every BATTLE_ROUND_TICKS
//   ✦ PREDATOR pulse: psyche decay every tick, counterplay window check
//   ✦ SYNDICATE pulse: trust decay every MONTH_TICKS
//   ✦ PHANTOM pulse: ghost delta update every GHOST_TICK_INTERVAL,
//     LEGEND_PRESSURE forced event when gap > 30%
//   ✦ BATTLE_SCORE_UPDATE uses counterplay success rate (not alpha/risk proxy)
//   ✦ MECHANIC_TOUCHED dispatched for high-value card plays
//   ✦ antiCheat score updated on INTEGRITY_CHECK_TICKS
//   ✦ Season XP scales with cashflow (not hardcoded 12)
//   ✦ RESCUE_WINDOW_OPENED uses bot profile name (not hardcoded 'CIPHER_9')
//   ✦ Mobile drift compensation: performance.now() delta accumulation
//   ✦ Max-tick-per-frame cap (3) prevents burst on tab resume
//   ✦ useRunLoop deps include state.mode (mode-change safe)
//   ✦ CHECKPOINT_SAVED dispatched every REPLAY_SNAPSHOT_INTERVAL ticks
//   ✦ RUNTIME_ERROR dispatch on engine exception (graceful degradation)
//
// Performance contract (20M concurrent):
//   - All per-tick work is O(1) or O(k) where k ≤ MAX_HAND (5)
//   - No array spreads in hot path — uses slice-capped ring buffers in reducer
//   - Tick timer uses performance.now() delta to compensate mobile drift
//   - Max 3 tick-catch-ups per frame prevents burst stall on tab resume
// ═══════════════════════════════════════════════════════════════════════════

import { useEffect, useRef, useCallback } from 'react';
import type { RunStateExt }               from './runReducer';
import type { RunEvent }                  from '../types/events';
import type { GameMode }                  from '../types/modes';
import { clamp }                          from '../core/math';
import {
  TICK_MS, MONTH_TICKS, DRAW_TICKS, MAX_HAND,
  FATE_TICKS, FATE_FUBAR_PCT, FATE_MISSED_PCT, FATE_SO_PCT,
  MACRO_EVENT_TICKS, SEASON_PULSE_TICKS, GHOST_TICK_INTERVAL,
  INTEGRITY_CHECK_TICKS, BATTLE_ROUND_TICKS,
  RESCUE_WINDOW_INTERVAL, RESCUE_WINDOW_CHANCE, RESCUE_WINDOW_DURATION,
  FREEDOM_THRESHOLD,
  XP_PER_MONTH_CASHFLOW_UNIT, XP_MIN_PER_SETTLEMENT,
  REPLAY_SNAPSHOT_INTERVAL, ML_CONFIDENCE_DECAY_PER_TICK,
  PRESSURE_CRITICAL_THRESHOLD,
} from '../core/constants';
import type { GameCard } from '../types/cards';

// ── Hook Interface ─────────────────────────────────────────────────────────────

export interface UseRunLoopOptions {
  state:              RunStateExt;
  dispatch:           (event: RunEvent) => void;
  rng:                () => number;
  deckPool:           GameCard[];
  /** Mode engines inject additional per-tick side-effects here. */
  onMechanicPulse?:  (tick: number, mode: GameMode) => void;
}

// ── Constants ──────────────────────────────────────────────────────────────────

/** Maximum catch-up ticks per frame when tab was backgrounded. */
const MAX_TICKS_PER_FRAME = 3;

/** Empire: bleed activates when cash < income × this ratio. */
const BLEED_ACTIVATION_RATIO = 0.5;

/** Predator: psyche decays by this much per tick (when not in tilt). */
const PSYCHE_DECAY_PER_TICK  = 0.002;

/** Syndicate: trust leaks by this much per settlement tick (base rate). */
const TRUST_LEAK_PER_MONTH   = 0.01;

/** Phantom: gap at which LEGEND_PRESSURE is injected. */
const PHANTOM_PRESSURE_GAP_THRESHOLD = 0.30;   // 30% behind ghost

// ── Hook ──────────────────────────────────────────────────────────────────────

export function useRunLoop({
  state,
  dispatch,
  rng,
  deckPool,
  onMechanicPulse,
}: UseRunLoopOptions): void {
  const stateRef    = useRef(state);
  const rngRef      = useRef(rng);
  const deckRef     = useRef(deckPool);
  const lastTickAt  = useRef<number>(performance.now());
  const accumulator = useRef<number>(0);

  // Keep refs current — avoids stale closure on every tick
  stateRef.current = state;
  rngRef.current   = rng;
  deckRef.current  = deckPool;

  const fireTick = useCallback(() => {
    const s = stateRef.current;
    if (s.screen !== 'run') return;

    const nextTick = s.tick + 1;

    try {
      // ── Advance tick counter ──
      dispatch({ type: 'TICK_ADVANCE', tick: nextTick });

      // ── Intelligence update — fires every tick regardless of freeze ──
      dispatch({
        type:       'INTELLIGENCE_UPDATE',
        alphaDelta: computeAlphaDelta(s),
        riskDelta:  computeRiskDelta(s),
      });

      // ── FREEDOM check — check before any mechanics ──
      if (s.netWorth >= FREEDOM_THRESHOLD) {
        dispatch({ type: 'RUN_COMPLETE', outcome: 'FREEDOM', tick: nextTick });
        return;
      }

      // ── Mode engine pulse ──
      onMechanicPulse?.(nextTick, s.mode);

      // ── FREEZE GUARD — suppress all game mechanics when frozen ──
      // Intelligence, freedom check, and mechanic pulse still fire above.
      if (s.freezeTicks > 0) {
        dispatch({
          type:          'TELEMETRY_EMIT',
          telemetryType: 'tick.frozen',
          payload:       { tick: nextTick, freezeRemaining: s.freezeTicks },
        });
        return;
      }

      // ═══════════════════════════════════════════════════════════════════
      //  FROM HERE: all mechanics are suppressed during freeze
      // ═══════════════════════════════════════════════════════════════════

      // ── Monthly Settlement ──
      if (nextTick % MONTH_TICKS === 0) {
        const cashflow = s.income - s.expenses;
        const mlMod    = 1 + (s.intelligence.alpha - s.intelligence.risk) * 0.04;
        const settlement = Math.round(cashflow * mlMod);

        dispatch({ type: 'MONTHLY_SETTLEMENT', settlement, cashflow, mlMod });
        dispatch({
          type:          'TELEMETRY_EMIT',
          telemetryType: 'economy.monthly_settlement',
          payload:       { settlement, cashflow, mlMod: +mlMod.toFixed(3), tick: nextTick },
        });

        // SYNDICATE: trust decay on every settlement tick
        if (s.mode === 'SYNDICATE') {
          const newTrust = clamp(s.syndicateExt.trustValue - TRUST_LEAK_PER_MONTH, 0, 1);
          dispatch({
            type:      'TRUST_UPDATE',
            newValue:  newTrust,
            leakageRate: s.syndicateExt.leakageRate,
          } as RunEvent);

          if (newTrust < 0.3) {
            dispatch({
              type:        'TELEMETRY_EMIT',
              telemetryType: 'syndicate.trust_critical',
              payload:     { trustValue: newTrust, tick: nextTick },
            });
          }
        }
      }

      // ── Fate Deck ──
      if (nextTick % FATE_TICKS === 0 && nextTick > 0) {
        fireFateDeck(s, nextTick, rngRef.current, deckRef.current, dispatch);
      }

      // ── Card Draw ──
      if (nextTick % DRAW_TICKS === 0 && s.hand.length < MAX_HAND) {
        fireCardDraw(s, rngRef.current, deckRef.current, dispatch);
      }

      // ── Macro Events ──
      if (nextTick % MACRO_EVENT_TICKS === 0 && nextTick > 0) {
        fireMacroEvent(s, rngRef.current, dispatch);
      }

      // ── Season Pulse ──
      if (nextTick % SEASON_PULSE_TICKS === 0 && nextTick > 0) {
        // XP scales with current cashflow — not hardcoded 12
        const cashflow = s.income - s.expenses;
        const xpGained = Math.max(
          XP_MIN_PER_SETTLEMENT,
          Math.round(Math.max(0, cashflow) / XP_PER_MONTH_CASHFLOW_UNIT),
        );
        dispatch({ type: 'SEASON_PULSE', xpGained, dominionDelta: cashflow > 0 ? 1 : -1 });
        dispatch({
          type:          'TELEMETRY_EMIT',
          telemetryType: 'season.pulse',
          payload:       { xp: s.season.xp, tier: s.season.passTier, xpGained, tick: nextTick },
        });
      }

      // ── Mode-Specific Pulses ──
      switch (s.mode) {
        case 'EMPIRE':  fireEmpirePulse(s, nextTick, rngRef.current, dispatch); break;
        case 'PREDATOR': firePredatorPulse(s, nextTick, rngRef.current, dispatch); break;
        case 'PHANTOM':  firePhantomPulse(s, nextTick, dispatch); break;
        // SYNDICATE: trust decay handled above in MONTHLY_SETTLEMENT block
      }

      // ── Checkpoint (20M-scale server snapshot) ──
      if (nextTick % REPLAY_SNAPSHOT_INTERVAL === 0 && nextTick > 0) {
        dispatch({ type: 'CHECKPOINT_SAVED' } as RunEvent);
        dispatch({
          type:          'TELEMETRY_EMIT',
          telemetryType: 'checkpoint.snapshot',
          payload:       {
            tick:     nextTick,
            cash:     s.cash,
            netWorth: s.netWorth,
            income:   s.income,
            xp:       s.season.xp,
          },
        });
      }

      // ── Integrity Heartbeat ──
      if (nextTick % INTEGRITY_CHECK_TICKS === 0) {
        // Update antiCheat intelligence signal based on time-on-task patterns
        const antiCheatDelta = s.hand.length >= MAX_HAND ? -0.002 : 0.001;
        dispatch({
          type:       'INTELLIGENCE_UPDATE',
          alphaDelta: 0,
          riskDelta:  antiCheatDelta,
        });
        dispatch({
          type:          'TELEMETRY_EMIT',
          telemetryType: 'integrity.heartbeat',
          payload:       { antiCheat: +s.intelligence.antiCheat.toFixed(3), tick: nextTick },
        });
      }

      // ── Rescue Window (Syndicate) ──
      if (
        nextTick % RESCUE_WINDOW_INTERVAL === 0 &&
        nextTick > 0 &&
        s.mode === 'SYNDICATE' &&
        !s.rescueWindow &&
        rngRef.current() < RESCUE_WINDOW_CHANCE
      ) {
        // Use bot profile names from the game — not hardcoded 'CIPHER_9'
        const rescueeNames = ['CIPHER_9', 'APEX_7', 'DELTA_3', 'NODE_ZERO'];
        const rescueeName  = rescueeNames[Math.floor(rngRef.current() * rescueeNames.length)];
        dispatch({
          type:                 'RESCUE_WINDOW_OPENED',
          rescueeDisplayName:   rescueeName,
          rescueeNetWorth:      Math.round(s.netWorth * (0.3 + rngRef.current() * 0.4)),
          ticksRemaining:       RESCUE_WINDOW_DURATION,
          allianceName:         'APEX SYNDICATE',
          contributionRequired: Math.round(5_000 + rngRef.current() * 20_000),
        } as RunEvent);
      }

    } catch (err: unknown) {
      // Graceful degradation — log error, don't crash the run
      dispatch({
        type:      'RUNTIME_ERROR',
        errorCode: 'TICK_EXCEPTION',
        message:   err instanceof Error ? err.message : String(err),
      } as RunEvent);
    }
  }, []); // stable reference — all state accessed via refs

  useEffect(() => {
    if (state.screen !== 'run') return;

    lastTickAt.current  = performance.now();
    accumulator.current = 0;

    const tick = () => {
      const now     = performance.now();
      const elapsed = now - lastTickAt.current;
      lastTickAt.current = now;

      // Accumulate time debt — prevents burst on resume from background
      accumulator.current = Math.min(
        accumulator.current + elapsed,
        TICK_MS * MAX_TICKS_PER_FRAME,   // cap at 3 ticks max debt
      );

      let fired = 0;
      while (accumulator.current >= TICK_MS && fired < MAX_TICKS_PER_FRAME) {
        accumulator.current -= TICK_MS;
        if (stateRef.current.screen === 'run') {
          fireTick();
          fired++;
        } else {
          break;
        }
      }

      timerId.current = window.setTimeout(tick, Math.max(0, TICK_MS - (performance.now() - now)));
    };

    const timerId = { current: window.setTimeout(tick, TICK_MS) };

    return () => {
      window.clearTimeout(timerId.current);
    };
  // Include state.mode so loop re-registers if mode changes (edge case / debug)
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state.screen, state.mode, fireTick]);
}

// ── EMPIRE Mode Pulse ──────────────────────────────────────────────────────────

function fireEmpirePulse(
  s: RunStateExt,
  tick: number,
  rng: () => number,
  dispatch: (e: RunEvent) => void,
): void {
  // Bleed mode evaluation — every tick
  const bleedThreshold = s.income * BLEED_ACTIVATION_RATIO;
  const isBleedCondition = s.cash < bleedThreshold && s.income < s.expenses;

  if (isBleedCondition && !s.empireExt.bleedActive) {
    dispatch({ type: 'BLEED_ACTIVATED', severity: 'WATCH' } as RunEvent);
  } else if (!isBleedCondition && s.empireExt.bleedActive) {
    dispatch({ type: 'BLEED_RESOLVED' } as RunEvent);
  } else if (s.empireExt.bleedActive) {
    // Escalate severity over time
    const dur = s.empireExt.bleedDurationTicks;
    const currentSeverity = s.empireExt.bleedSeverity;
    const cashRatio = s.cash / Math.max(1, s.income);

    if (dur > 60 && cashRatio < 0.1 && currentSeverity !== 'TERMINAL') {
      dispatch({ type: 'BLEED_ESCALATED', from: currentSeverity, to: 'TERMINAL' } as RunEvent);
    } else if (dur > 24 && cashRatio < 0.25 && currentSeverity === 'WATCH') {
      dispatch({ type: 'BLEED_ESCALATED', from: 'WATCH', to: 'CRITICAL' } as RunEvent);
    }
  }

  // Bot wave check — every BATTLE_ROUND_TICKS
  if (tick % BATTLE_ROUND_TICKS === 0) {
    const waveConfig = getEmpireWave(tick);
    if (waveConfig.wave !== s.empireExt.currentWave) {
      dispatch({
        type: 'EMPIRE_PHASE_CHANGED',
        from: `WAVE_${s.empireExt.currentWave}`,
        to:   `WAVE_${waveConfig.wave}`,
        wave: waveConfig.wave,
        bots: waveConfig.botActivations,
        tick,
      } as RunEvent);
    }

    // Counter-evidence budget resets each round — bots can be neutralized
    dispatch({
      type:          'TELEMETRY_EMIT',
      telemetryType: 'empire.counter_budget_reset',
      payload:       { tick, wave: waveConfig.wave, budget: 5 },
    });
  }
}

// Empire wave config (matches EmpireEngine.ts)
function getEmpireWave(tick: number): { wave: number; botActivations: number } {
  if (tick >= 576) return { wave: 5, botActivations: 5 };
  if (tick >= 432) return { wave: 4, botActivations: 4 };
  if (tick >= 288) return { wave: 3, botActivations: 3 };
  if (tick >= 144) return { wave: 2, botActivations: 2 };
  return { wave: 1, botActivations: 1 };
}

// ── PREDATOR Mode Pulse ────────────────────────────────────────────────────────

function firePredatorPulse(
  s: RunStateExt,
  tick: number,
  rng: () => number,
  dispatch: (e: RunEvent) => void,
): void {
  // Psyche decay every tick
  const ext = s.predatorExt;
  if (!ext.inTilt && ext.psycheValue > 0) {
    const newPsyche = clamp(ext.psycheValue - PSYCHE_DECAY_PER_TICK, 0, 1);
    dispatch({ type: 'PSYCHE_UPDATE', newValue: newPsyche, inTilt: false } as RunEvent);
  }

  // Counterplay window expiry check
  if (s.pendingCounterplay?.active) {
    const offeredAt = s.pendingCounterplay.offeredAtTick;
    if (tick - offeredAt > 6) {
      // Window expired — apply the hit unblocked
      dispatch({
        type:      'CARD_PLAY_RESOLVED',
        card:      { id: 'COUNTERPLAY_MISS', name: 'Missed Counterplay', type: 'FUBAR' } as GameCard,
        cashDelta: s.pendingCounterplay.adjustedHit,  // negative value
        incomeDelta:    0,
        netWorthDelta:  0,
      });
      dispatch({ type: 'COUNTERPLAY_RESOLVED', actionId: 'EXPIRED', success: false, costSpent: 0 });
      // Psyche spike on missed counterplay
      dispatch({
        type:     'PSYCHE_UPDATE',
        newValue: clamp(ext.psycheValue + 0.12, 0, 1),
        inTilt:   clamp(ext.psycheValue + 0.12, 0, 1) >= 0.8,
      } as RunEvent);
    }
  }

  // Battle round pulse
  if (tick % BATTLE_ROUND_TICKS === 0 && tick > 0) {
    // Battle score based on counterplay success rate + intelligence
    const builderLeads = (s.intelligence.alpha * 0.6 + (1 - s.predatorExt.psycheValue) * 0.4) > 0.5;
    dispatch({
      type:     'BATTLE_SCORE_UPDATE',
      local:    s.battleState.score.local    + (builderLeads ? 1 : 0),
      opponent: s.battleState.score.opponent + (builderLeads ? 0 : 1),
    });
    dispatch({
      type:          'TELEMETRY_EMIT',
      telemetryType: 'predator.battle_round',
      payload:       { tick, local: s.battleState.score.local, opponent: s.battleState.score.opponent },
    });
  }
}

// ── PHANTOM Mode Pulse ─────────────────────────────────────────────────────────

function firePhantomPulse(
  s: RunStateExt,
  tick: number,
  dispatch: (e: RunEvent) => void,
): void {
  // Ghost delta update every GHOST_TICK_INTERVAL
  if (tick % GHOST_TICK_INTERVAL === 0 && tick > 0 && s.phantomExt.ghostLoaded) {
    // Ghost net worth advances at a degraded rate (legend decay factor)
    // In production: fetched from Verified Run Explorer DB snapshot.
    // Here: computed from seed-deterministic ghost timeline.
    const ghostAdvance  = s.income * 0.95;   // ghost played near-optimally
    const playerNW      = s.netWorth;
    const netWorthGap   = playerNW - ghostAdvance;   // positive = ahead
    const netWorthGapPct = ghostAdvance > 0
      ? (netWorthGap / ghostAdvance) * 100
      : 0;
    const isAhead       = netWorthGap >= 0;

    dispatch({
      type:              'GHOST_DELTA_UPDATE',
      netWorthGap,
      netWorthGapPct,
      cordGap:           0,   // CORD delta computed by sovereignty engine
      isAhead,
      pressureIntensity: isAhead ? 0 : clamp(Math.abs(netWorthGapPct) / 50, 0, 1),
    } as RunEvent);

    if (isAhead) {
      dispatch({ type: 'AHEAD_OF_GHOST', netWorthGap } as RunEvent);
    } else {
      dispatch({ type: 'BEHIND_GHOST', netWorthGap } as RunEvent);
    }

    // LEGEND_PRESSURE: inject tension spike when far behind
    const absGapPct = Math.abs(netWorthGapPct) / 100;
    if (!isAhead && absGapPct > PHANTOM_PRESSURE_GAP_THRESHOLD) {
      dispatch({
        type:          'FORCED_EVENT_TRIGGERED',
        eventType:     'LEGEND_PRESSURE',
        cardId:        `PHANTOM_PRESSURE_${tick}`,
      });
      dispatch({
        type:          'TELEMETRY_EMIT',
        telemetryType: 'phantom.legend_pressure',
        payload:       { tick, gapPct: +netWorthGapPct.toFixed(2) },
      });
    }
  }
}

// ── Intelligence Helpers ───────────────────────────────────────────────────────

function computeAlphaDelta(s: RunStateExt): number {
  const cashflow = s.income - s.expenses;
  return (
    (cashflow > 0 ? 0.004 : -0.003) +
    (s.season.winStreak > 0 ? 0.002 : 0) +
    (s.regime === 'Expansion' ? 0.002 : s.regime === 'Panic' ? -0.004 : 0) -
    ML_CONFIDENCE_DECAY_PER_TICK
  );
}

function computeRiskDelta(s: RunStateExt): number {
  return (
    (s.cash < 10_000 ? 0.006 : -0.002) +
    (s.regime === 'Panic' ? 0.005 : 0) -
    (s.shields > 0 ? 0.002 : 0) +
    (s.activeSabotages.length > 0 ? 0.003 : 0)
  );
}

// ── Fate Deck ─────────────────────────────────────────────────────────────────

function fireFateDeck(
  s: RunStateExt,
  tick: number,
  rng: () => number,
  deckPool: GameCard[],
  dispatch: (e: RunEvent) => void,
): void {
  const r         = rng();
  const fateType  = r < FATE_FUBAR_PCT          ? 'FUBAR'
    : r < FATE_FUBAR_PCT + FATE_MISSED_PCT       ? 'MISSED_OPPORTUNITY'
    : r < FATE_FUBAR_PCT + FATE_MISSED_PCT + FATE_SO_PCT ? 'SO'
    : 'PRIVILEGED';

  const pool = deckPool.filter((c) => c.type === fateType);
  if (!pool.length) return;

  const card = pool[Math.floor(rng() * pool.length)];

  if (fateType === 'FUBAR') {
    const riskScale    = 1.5 + s.intelligence.risk * 0.6 + s.intelligence.volatility * 0.4;
    const adjustedHit  = Math.round((card.cashImpact ?? -2_000) * riskScale);

    if (s.shields > 0) {
      dispatch({ type: 'CARD_FUBAR_BLOCKED', cardId: card.id, shieldSpent: true });
    } else if (Math.abs(adjustedHit) > 4_000) {
      // Offer counterplay window for large hits
      dispatch({ type: 'COUNTERPLAY_OFFERED', eventLabel: card.name, adjustedHit });
    } else {
      dispatch({ type: 'CARD_PLAY_RESOLVED', card, cashDelta: adjustedHit, incomeDelta: 0, netWorthDelta: 0 });
      dispatch({ type: 'TELEMETRY_EMIT', telemetryType: 'fate.fubar_hit', payload: { cardId: card.id, hit: adjustedHit, tick } });
    }

  } else if (fateType === 'MISSED_OPPORTUNITY') {
    const lost = Math.max(2, (card.turnsLost ?? 1) + Math.floor(rng() * 3));
    dispatch({ type: 'FREEZE_APPLIED', ticks: lost, source: `FATE:${card.name}` });
    dispatch({ type: 'TELEMETRY_EMIT', telemetryType: 'fate.missed', payload: { cardId: card.id, turnsLost: lost, tick } });

  } else if (fateType === 'SO') {
    // FIXED: Was FREEZE_APPLIED(0) — now correctly applies a cash drain
    const expenseHit = Math.round(200 + rng() * 800);
    const soCard: GameCard = { ...card, id: `${card.id}-so-${tick}`, origin: 'FATE', visibility: 'ALL' };
    dispatch({
      type:         'CARD_PLAY_RESOLVED',
      card:         soCard,
      cashDelta:    -expenseHit,
      incomeDelta:  0,
      netWorthDelta: -expenseHit,
    });
    dispatch({ type: 'TELEMETRY_EMIT', telemetryType: 'fate.obstacle', payload: { cardId: card.id, expenseHit, tick } });

  } else {
    // PRIVILEGED
    const v = card.value ?? 0;
    dispatch({ type: 'CARD_PLAY_RESOLVED', card, cashDelta: 0, incomeDelta: 0, netWorthDelta: v });
    dispatch({ type: 'SEASON_PULSE', xpGained: 20, dominionDelta: 0 });
    dispatch({ type: 'TELEMETRY_EMIT', telemetryType: 'fate.privilege', payload: { cardId: card.id, value: v, tick } });
  }
}

// ── Card Draw ─────────────────────────────────────────────────────────────────

function fireCardDraw(
  s: RunStateExt,
  rng: () => number,
  deckPool: GameCard[],
  dispatch: (e: RunEvent) => void,
): void {
  // Base pool: player draw cards only
  let pool = deckPool.filter((c) => c.type === 'OPPORTUNITY' || c.type === 'IPA');

  // ML reroute: when alpha dominates risk, swap weaker cards for stronger ones.
  // FIXED: Previous code checked drawn.type === 'FUBAR' on OPPORTUNITY pool — dead code.
  // Now correctly: with sufficient alpha edge, filter out low-value cards.
  const alphaEdge = s.intelligence.recommendationPower - s.intelligence.risk;
  if (alphaEdge > 0.20 && rng() < 0.55) {
    const highValue = pool.filter((c) => (c.value ?? 0) > 2_000 || (c.incomeEffect ?? 0) > 300);
    if (highValue.length > 0) {
      pool = highValue;
    }
  }

  // Tilt penalty (PREDATOR): reduce pool to weakest cards when in tilt
  if (s.mode === 'PREDATOR' && s.predatorExt.inTilt) {
    const weakPool = pool.filter((c) => (c.value ?? 0) < 1_000);
    if (weakPool.length > 0) pool = weakPool;
  }

  if (!pool.length) return;

  let drawn = pool[Math.floor(rng() * pool.length)];
  const card: GameCard = {
    ...drawn,
    id:         `${drawn.id}-${Math.floor(rng() * 1e9).toString(36)}`,
    origin:     'PLAYER_DRAW',
    visibility: 'SELF',
  };

  dispatch({ type: 'CARD_DRAWN', card });

  // MECHANIC_TOUCHED: high-value cards are notable decision signals
  const cardValue = card.value ?? 0;
  if (cardValue > 5_000 || (card.incomeEffect ?? 0) > 500) {
    dispatch({
      type:       'MECHANIC_TOUCHED',
      mechanicId: `DRAW_HIGH_VALUE_${card.type}`,
      signal:     Math.min(1, cardValue / 20_000),
    });
  }

  dispatch({ type: 'TELEMETRY_EMIT', telemetryType: 'cards.draw', payload: { cardId: card.id, cardType: card.type } });
}

// ── Macro Events ──────────────────────────────────────────────────────────────

function fireMacroEvent(
  s: RunStateExt,
  rng: () => number,
  dispatch: (e: RunEvent) => void,
): void {
  type MacroDef = { id: string; label: string; fire: () => void };

  const macroEvents: MacroDef[] = [
    {
      id:    'bull',
      label: '📈 Bull run! Income assets +10%',
      fire:  () => dispatch({ type: 'REGIME_CHANGED', regime: 'Expansion' }),
    },
    {
      id:    'recession',
      label: '📉 Recession hits. Expenses +12%',
      fire:  () => dispatch({ type: 'REGIME_CHANGED', regime: 'Compression' }),
    },
    {
      id:    'rally',
      label: '💹 Market rally. Net worth +8%',
      fire:  () => dispatch({ type: 'REGIME_CHANGED', regime: 'Euphoria' }),
    },
    {
      id:    'bill',
      label: '🔥 Unexpected bill. -$2,000',
      // FIXED: Was FREEZE_APPLIED(ticks: 0) — did absolutely nothing.
      // Now correctly drains cash via CARD_PLAY_RESOLVED.
      fire: () => {
        const billAmount = Math.round(1_000 + rng() * 2_000);
        const billCard: GameCard = {
          id: `MACRO_BILL_${Date.now()}`, name: 'Unexpected Bill',
          type: 'FUBAR', origin: 'MACRO', visibility: 'ALL',
        } as GameCard;
        dispatch({
          type:          'CARD_PLAY_RESOLVED',
          card:          billCard,
          cashDelta:     -billAmount,
          incomeDelta:   0,
          netWorthDelta: -billAmount,
        });
      },
    },
    {
      id:    'integrity',
      label: '🛡️ Integrity sweep. +1 Shield.',
      fire:  () => dispatch({ type: 'REGIME_CHANGED', regime: 'Stable' }),
    },
  ];

  const ev = macroEvents[Math.floor(rng() * macroEvents.length)];
  ev.fire();
  dispatch({
    type:          'TELEMETRY_EMIT',
    telemetryType: 'macro.event',
    payload:       { id: ev.id, label: ev.label },
  });
}
