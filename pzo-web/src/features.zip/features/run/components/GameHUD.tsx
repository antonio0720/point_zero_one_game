import React, { useState }    from 'react';
import { useIntel }           from '../../../ml/wiring/MLContext';
import PressureGauge          from './PressureGauge';
import PressureSignalTooltip  from './PressureSignalTooltip';

// ── Intel Bar Types ────────────────────────────────────────────────────────────

interface IntelBarDef {
  key:      string;
  label:    string;
  value:    number;          // 0–1
  color:    string;          // Tailwind bg class
  warning?: boolean;         // highlights bar red when true
}

// ── Intel Bars Sub-Component ──────────────────────────────────────────────────

const IntelBars: React.FC = () => {
  const intel = useIntel();

  const bars: IntelBarDef[] = [
    {
      key:     'alpha',
      label:   'Alpha',
      value:   intel.alpha,
      color:   'bg-emerald-500',
    },
    {
      key:     'risk',
      label:   'Risk',
      value:   intel.risk,
      color:   'bg-amber-500',
      warning: intel.risk > 0.7,
    },
    {
      key:     'volatility',
      label:   'Volatility',
      value:   intel.volatility,
      color:   'bg-sky-500',
    },
    {
      key:     'tiltRisk',
      label:   'Tilt',
      value:   intel.tiltRisk,
      color:   'bg-orange-500',
      warning: intel.tiltRisk > 0.5,
    },
    {
      key:     'bankruptcyRisk60',
      label:   'Runway',
      // Invert so full bar = safe, empty bar = critical
      value:   1 - intel.bankruptcyRisk60,
      color:   'bg-rose-600',
      warning: intel.bankruptcyRisk60 > 0.6,
    },
  ];

  return (
    <div className="intel-bars" aria-label="Intelligence Dashboard">
      {bars.map((bar) => (
        <div key={bar.key} className="intel-bar-row">
          <span className="intel-bar-label">{bar.label}</span>
          <div className="intel-bar-track">
            <div
              className={`intel-bar-fill ${bar.warning ? 'bg-red-600' : bar.color}`}
              style={{ width: `${Math.round(bar.value * 100)}%` }}
              role="progressbar"
              aria-valuenow={Math.round(bar.value * 100)}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label={bar.label}
            />
          </div>
          <span className="intel-bar-value">
            {Math.round(bar.value * 100)}
          </span>
        </div>
      ))}

      {/* Momentum indicator — can be negative */}
      <div className="intel-momentum-row">
        <span className="intel-bar-label">Momentum</span>
        <span
          className={`intel-momentum-value ${
            intel.momentum > 0.05  ? 'text-emerald-400' :
            intel.momentum < -0.05 ? 'text-rose-400' :
            'text-zinc-400'
          }`}
        >
          {intel.momentum >= 0 ? '+' : ''}{(intel.momentum * 100).toFixed(1)}
        </span>
      </div>
    </div>
  );
};

// ── GameHUD ────────────────────────────────────────────────────────────────────

interface GameHUDProps {
  readonly pressureData:   number;
  readonly isActiveRun?:   boolean;
  /** Set false to hide intel bars (e.g. during pause screen) */
  readonly showIntel?:     boolean;
}

const PressureGaugeWrapper = ({ pressureData }: Readonly<Pick<GameHUDProps, 'pressureData'>>) => (
  <PressureGauge data-pressure={pressureData} />
);

const GameHUD: React.FC<GameHUDProps> = ({
  pressureData,
  isActiveRun,
  showIntel = true,
}) => {
  const [hoveredPressureGaugeIndex, setHoveredPressureGaugeIndex] = useState(-1);

  return (
    <div className="game-hud">
      {isActiveRun && (
        <>
          <PressureGaugeWrapper pressureData={pressureData} />
          {hoveredPressureGaugeIndex >= 0 && (
            <PressureSignalTooltip
              index={hoveredPressureGaugeIndex}
              data-pressure={pressureData}
            />
          )}
          {showIntel && <IntelBars />}
        </>
      )}
    </div>
  );
};

export default GameHUD;