//Users/mervinlarry/workspaces/adam/Projects/adam/point_zero_one_master/pzo-web/src/features/run/components/CardHand.tsx

// pzo-web/src/features/run/components/CardHand.tsx
//
// ═══════════════════════════════════════════════════════════════════════════════
// POINT ZERO ONE — CARD HAND
//
// Full hand display component.
// Renders up to N CardSlot components in a fan layout.
// Wraps each slot in a DecisionTimerRing.
// Mode-aware across all 4 game modes.
//
// MODE FEATURES:
//   GO_ALONE     — Hold slot panel, chain synergy indicator, phase boundary banner
//   HEAD_TO_HEAD — Battle Budget gauge, counter window flash border
//   TEAM_UP      — Trust score badge, rescue window pulse, AID terms counter
//   CHASE_A_LEGEND — Divergence gap bar, ghost marker pips
//
// INTERACTIONS:
//   Click / tap  — plays card (queued to engine via dispatchPlay)
//   Long press   — hold card (Empire only, dispatches dispatchHold)
//   Drag to zone — drop zone at bottom accepts drag-released cards
//   Forced cards — always rendered first, pulsing red border
//
// RULES:
//   ✦ Zero engine imports — reads exclusively from useCardHand + useAllDecisionWindows.
//   ✦ All card play intents dispatched through useCardHand action functions.
//   ✦ Fan rotation injected as inline transform via CSS custom property.
//
// Density6 LLC · Point Zero One · Cards Engine · Confidential
// ═══════════════════════════════════════════════════════════════════════════════

import React, {
  useMemo,
  useCallback,
  useRef,
  useState,
  useEffect,
} from 'react';

import { useCardHand, getCardCostLabel, getTrustModifierLabel, getDivergenceLabel } from '../hooks/useCardHand';
import { useAllDecisionWindows } from '../hooks/useDecisionWindow';
import { DecisionTimerRing } from './DecisionTimerRing';
import { CardSlot } from './CardSlot';

import {
  GameMode,
  TimingClass,
  CardRarity,
  type CardInHand,
  type CardPlayRequest,
} from '../../../engines/cards/types';

// ── FAN LAYOUT CONFIG ─────────────────────────────────────────────────────────

/** Total arc spread in degrees for the hand fan. */
const FAN_SPREAD_DEG  = 18;
/** Vertical lift applied to the center card (px). */
const FAN_LIFT_PX     = 14;
/** Horizontal overlap between adjacent cards (px). */
const FAN_OVERLAP_PX  = 54;

// ── LONG-PRESS THRESHOLD (ms) — triggers hold on Empire ──────────────────────
const LONG_PRESS_MS   = 500;

// ─────────────────────────────────────────────────────────────────────────────
// HELPERS
// ─────────────────────────────────────────────────────────────────────────────

/** Compute per-slot fan transform based on hand size and slot index. */
function slotTransform(index: number, total: number, isHovered: boolean): React.CSSProperties {
  if (total === 0) return {};

  // Step angle between cards, capped by max spread
  const step    = total > 1 ? FAN_SPREAD_DEG / (total - 1) : 0;
  const rotDeg  = total > 1 ? -FAN_SPREAD_DEG / 2 + step * index : 0;

  // Vertical arc: center card is highest, edge cards droop
  const midIdx  = (total - 1) / 2;
  const dist    = Math.abs(index - midIdx) / Math.max(1, (total - 1) / 2);
  const liftPx  = FAN_LIFT_PX * (1 - dist * dist);

  if (isHovered) {
    return {
      transform:      `translateY(-22px) scale(1.06)`,
      zIndex:         20,
      transition:     'transform 0.20s cubic-bezier(0.34,1.56,0.64,1)',
    };
  }

  return {
    transform:      `rotate(${rotDeg}deg) translateY(${-liftPx}px)`,
    transformOrigin:'center bottom',
    transition:     'transform 0.22s cubic-bezier(0.34,1.56,0.64,1), z-index 0s',
  };
}

/** Map mode enum to CSS theme class. */
function modeClass(mode: GameMode): string {
  const map: Record<GameMode, string> = {
    [GameMode.GO_ALONE]:       'pzo-hand--empire',
    [GameMode.HEAD_TO_HEAD]:   'pzo-hand--predator',
    [GameMode.TEAM_UP]:        'pzo-hand--syndicate',
    [GameMode.CHASE_A_LEGEND]: 'pzo-hand--phantom',
  };
  return map[mode] ?? '';
}

// ─────────────────────────────────────────────────────────────────────────────
// HOLD SLOT (Empire only)
// ─────────────────────────────────────────────────────────────────────────────

interface HoldSlotPanelProps {
  holdSlot:        ReturnType<typeof useCardHand>['holdSlot'];
  onRelease:       () => void;
  chainSynergyActive: boolean;
}

const HoldSlotPanel: React.FC<HoldSlotPanelProps> = ({
  holdSlot,
  onRelease,
  chainSynergyActive,
}) => (
  <div
    className={`pzo-hold-slot ${holdSlot ? 'pzo-hold-slot--occupied' : ''}`}
    onClick={holdSlot ? onRelease : undefined}
    title={holdSlot ? 'Click to release held card' : 'Hold slot — Empire'}
    aria-label={holdSlot ? `Hold slot: ${holdSlot.card.definition.name} — click to release` : 'Empty hold slot'}
    role={holdSlot ? 'button' : 'presentation'}
    tabIndex={holdSlot ? 0 : -1}
  >
    {holdSlot ? (
      <>
        <CardSlot card={holdSlot.card} isHeld windowInfo={null} onPlay={() => {}} />
        <span className="pzo-hold-slot__release-hint">↑ release</span>
      </>
    ) : (
      <span className="pzo-hold-slot__label">HOLD</span>
    )}

    {chainSynergyActive && (
      <div className="pzo-chain-indicator" aria-label="IPA chain synergy active">
        <div className="pzo-chain-indicator__dot" />
        <div className="pzo-chain-indicator__dot" />
        <div className="pzo-chain-indicator__dot" />
      </div>
    )}
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
// BATTLE BUDGET GAUGE (Predator)
// ─────────────────────────────────────────────────────────────────────────────

const BattleBudgetGauge: React.FC<{
  budget: number;
  max:    number;
  counterWindowOpen: boolean;
}> = ({ budget, max, counterWindowOpen }) => {
  const pct = max > 0 ? Math.round((budget / max) * 100) : 0;
  return (
    <div
      className={`pzo-bb-gauge ${counterWindowOpen ? 'pzo-bb-gauge--counter-active' : ''}`}
      aria-label={`Battle Budget: ${budget} / ${max}`}
    >
      <div className="pzo-bb-gauge__label">BB</div>
      <div className="pzo-bb-gauge__track">
        <div
          className="pzo-bb-gauge__fill"
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="pzo-bb-gauge__value">{budget}</div>
      {counterWindowOpen && (
        <div className="pzo-bb-gauge__counter-flash" aria-live="assertive">
          COUNTER WINDOW
        </div>
      )}
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// TRUST SCORE BADGE (Syndicate)
// ─────────────────────────────────────────────────────────────────────────────

const TrustBadge: React.FC<{
  score:      number;
  multiplier: number;
  rescueWindowOpen: boolean;
}> = ({ score, multiplier, rescueWindowOpen }) => (
  <div
    className={`pzo-trust-badge ${rescueWindowOpen ? 'pzo-trust-badge--rescue' : ''}`}
    aria-label={`Trust Score: ${score}`}
  >
    <span className="pzo-trust-badge__label">TRUST</span>
    <span className="pzo-trust-badge__score">{score}</span>
    {multiplier !== 1.0 && (
      <span className={`pzo-trust-badge__mod ${multiplier > 1 ? 'pzo-trust-badge__mod--pos' : 'pzo-trust-badge__mod--neg'}`}>
        {getTrustModifierLabel(multiplier)}
      </span>
    )}
    {rescueWindowOpen && (
      <span className="pzo-trust-badge__rescue-flag" aria-live="assertive">⚠ RESCUE</span>
    )}
  </div>
);

// ─────────────────────────────────────────────────────────────────────────────
// DIVERGENCE BAR (Phantom)
// ─────────────────────────────────────────────────────────────────────────────

const DivergenceBar: React.FC<{
  currentGap: number;
  score:      number;
}> = ({ currentGap, score }) => {
  const pct     = Math.round(currentGap * 100);
  const barPct  = Math.max(2, Math.min(100, pct));
  const color   = pct < 20 ? '#22c55e' : pct < 50 ? '#8b5cf6' : '#ef4444';

  return (
    <div className="pzo-divergence-bar" aria-label={`Divergence: ${pct}% behind legend`}>
      <div className="pzo-divergence-bar__label">{getDivergenceLabel(currentGap)}</div>
      <div className="pzo-divergence-bar__track">
        <div
          className="pzo-divergence-bar__fill"
          style={{ width: `${barPct}%`, background: color }}
        />
      </div>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// MISSED STREAK INDICATOR
// ─────────────────────────────────────────────────────────────────────────────

const MissedStreakBadge: React.FC<{ streak: number }> = ({ streak }) => {
  if (streak < 2) return null;
  return (
    <div
      className={`pzo-streak-indicator pzo-streak-indicator--visible pzo-streak-indicator--${Math.min(streak, 4)}`}
      role="alert"
      aria-live="polite"
    >
      {streak}× MISS
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// CARD HAND — MAIN COMPONENT
// ─────────────────────────────────────────────────────────────────────────────

export interface CardHandProps {
  className?: string;
}

export const CardHand: React.FC<CardHandProps> = ({ className = '' }) => {
  const {
    hand,
    playableCards,
    forcedCards,
    holdSlot,
    handSize,
    hasForcedPending,
    gameMode,
    battleBudget,
    trustScore,
    trustMultiplier,
    divergenceScore,
    currentGap,
    chainSynergyActive,
    phaseBoundaryOpen,
    currentPhase,
    missedStreak,
    isReplenishing,
    draggedCard,
    isDragging,
    dispatchPlay,
    dispatchHold,
    dispatchRelease,
    onDragStart,
    onDragEnd,
  } = useCardHand();

  // Pull mode-specific values from store directly when needed
  const { battleBudgetMax, counterWindowOpen, rescueWindowOpen } =
    useModeExtras(gameMode);

  // ── Decision windows — single rAF loop for entire hand ──────────────────
  const instanceIds  = useMemo(() => hand.map(c => c.instanceId), [hand]);
  const windowInfos  = useAllDecisionWindows(instanceIds);

  // ── Hovered slot index ──────────────────────────────────────────────────
  const [hoveredIdx, setHoveredIdx]   = useState<number | null>(null);

  // ── Drop zone active ────────────────────────────────────────────────────
  const [dropActive, setDropActive]   = useState(false);
  const [dropHighlight, setDropHighlight] = useState(false);

  // ── Long-press ref (Empire hold) ────────────────────────────────────────
  const longPressRef  = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ── Ordered cards: forced first, then rest ──────────────────────────────
  const orderedHand = useMemo(() => {
    const forced  = hand.filter(c => c.isForced);
    const regular = hand.filter(c => !c.isForced && !c.isHeld);
    return [...forced, ...regular];
  }, [hand]);

  // ── Play handler ─────────────────────────────────────────────────────────
  const handlePlay = useCallback((card: CardInHand) => {
    if (card.isHeld) return;
    const request: CardPlayRequest = {
      instanceId: card.instanceId,
      choiceId:   'default',
      timestamp:  Date.now(),
    };
    dispatchPlay(request);
  }, [dispatchPlay]);

  // ── Long-press → hold (Empire) ────────────────────────────────────────
  const handlePointerDown = useCallback((card: CardInHand) => {
    if (gameMode !== GameMode.GO_ALONE) return;
    longPressRef.current = setTimeout(() => {
      dispatchHold(card.instanceId);
    }, LONG_PRESS_MS);
  }, [gameMode, dispatchHold]);

  const handlePointerUp = useCallback(() => {
    if (longPressRef.current) {
      clearTimeout(longPressRef.current);
      longPressRef.current = null;
    }
  }, []);

  // ── Drag handlers ─────────────────────────────────────────────────────
  const handleDragStart = useCallback((card: CardInHand, e: React.DragEvent) => {
    e.dataTransfer.setData('cardInstanceId', card.instanceId);
    onDragStart(card);
    setDropActive(true);
  }, [onDragStart]);

  const handleDragEnd = useCallback(() => {
    onDragEnd();
    setDropActive(false);
    setDropHighlight(false);
  }, [onDragEnd]);

  const handleDropZoneDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDropHighlight(true);
  }, []);

  const handleDropZoneDragLeave = useCallback(() => {
    setDropHighlight(false);
  }, []);

  const handleDropZoneDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    const instanceId = e.dataTransfer.getData('cardInstanceId');
    const card = hand.find(c => c.instanceId === instanceId);
    if (card) handlePlay(card);
    setDropActive(false);
    setDropHighlight(false);
    onDragEnd();
  }, [hand, handlePlay, onDragEnd]);

  // Clean up long press on unmount
  useEffect(() => {
    return () => {
      if (longPressRef.current) clearTimeout(longPressRef.current);
    };
  }, []);

  // ── Keyboard: Enter/Space plays hovered card ───────────────────────────
  const handleKeyDown = useCallback((e: React.KeyboardEvent, card: CardInHand) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      handlePlay(card);
    }
  }, [handlePlay]);

  // ─────────────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────────────

  const handClasses = [
    'pzo-hand',
    modeClass(gameMode),
    className,
    hasForcedPending ? 'pzo-hand--has-forced' : '',
    isDragging       ? 'pzo-hand--dragging' : '',
  ].filter(Boolean).join(' ');

  return (
    <div className="pzo-hand-root">

      {/* ── Mode HUD strip ────────────────────────────────────────────── */}
      <div className="pzo-hand-hud">
        {/* Missed streak */}
        <MissedStreakBadge streak={missedStreak} />

        {/* Empire: phase boundary banner */}
        {gameMode === GameMode.GO_ALONE && phaseBoundaryOpen && (
          <div className="pzo-phase-boundary-banner" role="alert" aria-live="assertive">
            {currentPhase} — PHASE WINDOW OPEN
          </div>
        )}

        {/* Predator: battle budget */}
        {gameMode === GameMode.HEAD_TO_HEAD && (
          <BattleBudgetGauge
            budget={battleBudget}
            max={battleBudgetMax}
            counterWindowOpen={counterWindowOpen}
          />
        )}

        {/* Syndicate: trust score */}
        {gameMode === GameMode.TEAM_UP && (
          <TrustBadge
            score={trustScore}
            multiplier={trustMultiplier}
            rescueWindowOpen={rescueWindowOpen}
          />
        )}

        {/* Phantom: divergence bar */}
        {gameMode === GameMode.CHASE_A_LEGEND && (
          <DivergenceBar currentGap={currentGap} score={divergenceScore} />
        )}
      </div>

      {/* ── Hand row: hold slot + fan ─────────────────────────────────── */}
      <div style={{ display: 'flex', alignItems: 'flex-end', justifyContent: 'center', gap: 12 }}>

        {/* Empire hold slot — renders left of hand */}
        {gameMode === GameMode.GO_ALONE && (
          <HoldSlotPanel
            holdSlot={holdSlot}
            onRelease={dispatchRelease}
            chainSynergyActive={chainSynergyActive}
          />
        )}

        {/* Fan container */}
        <div
          className={handClasses}
          role="list"
          aria-label={`Card hand — ${handSize} card${handSize !== 1 ? 's' : ''}`}
        >
          {orderedHand.map((card, idx) => {
            const isPlayable    = !hasForcedPending || card.isForced || card.definition.timingClass === TimingClass.LEGENDARY;
            const isHovered     = hoveredIdx === idx;
            const windowInfo    = windowInfos[card.instanceId] ?? null;
            const isDraggingThis = draggedCard?.instanceId === card.instanceId;

            const slotClasses = [
              'pzo-hand__slot',
              isHovered         ? 'pzo-hand__slot--hovered' : '',
              isDraggingThis    ? 'pzo-hand__slot--dragging' : '',
              !isPlayable       ? 'pzo-hand__slot--unplayable' : '',
              isReplenishing && idx === orderedHand.length - 1 ? 'pzo-hand__slot--replenishing' : '',
            ].filter(Boolean).join(' ');

            return (
              <div
                key={card.instanceId}
                className={slotClasses}
                style={{
                  ...slotTransform(idx, orderedHand.length, isHovered),
                  zIndex: isHovered ? 20 : hasForcedPending && card.isForced ? 15 : 10 + idx,
                  marginLeft: idx === 0 ? 0 : -FAN_OVERLAP_PX,
                }}
                role="listitem"
                onMouseEnter={() => setHoveredIdx(idx)}
                onMouseLeave={() => setHoveredIdx(null)}
                onPointerDown={() => handlePointerDown(card)}
                onPointerUp={handlePointerUp}
                onPointerCancel={handlePointerUp}
                draggable={isPlayable}
                onDragStart={e => handleDragStart(card, e)}
                onDragEnd={handleDragEnd}
                onClick={() => isPlayable && handlePlay(card)}
                onKeyDown={e => isPlayable && handleKeyDown(e, card)}
                tabIndex={isPlayable ? 0 : -1}
                aria-label={`${card.definition.name} — ${getCardCostLabel(card, gameMode)} — ${card.definition.timingClass}`}
                aria-disabled={!isPlayable}
              >
                <DecisionTimerRing
                  cardInstanceId={card.instanceId}
                  showCountdown={isHovered}
                >
                  <CardSlot
                    card={card}
                    isHeld={card.isHeld}
                    windowInfo={windowInfo}
                    gameMode={gameMode}
                    isPlayable={isPlayable}
                    onPlay={() => isPlayable && handlePlay(card)}
                  />
                </DecisionTimerRing>
              </div>
            );
          })}

          {/* Empty state */}
          {orderedHand.length === 0 && (
            <div className="pzo-hand__empty" aria-live="polite">
              {isReplenishing ? 'Drawing…' : 'No cards in hand'}
            </div>
          )}
        </div>
      </div>

      {/* ── Drag-to-play drop zone ─────────────────────────────────────── */}
      <div
        className={[
          'pzo-drop-zone',
          dropActive    ? 'pzo-drop-zone--active' : '',
          dropHighlight ? 'pzo-drop-zone--highlight' : '',
        ].filter(Boolean).join(' ')}
        onDragOver={handleDropZoneDragOver}
        onDragLeave={handleDropZoneDragLeave}
        onDrop={handleDropZoneDrop}
        aria-label="Drop zone — drag a card here to play it"
        aria-hidden={!dropActive}
      >
        PLAY
      </div>
    </div>
  );
};

export default CardHand;

// ─────────────────────────────────────────────────────────────────────────────
// useModeExtras — reads mode-specific store values unavailable in useCardHand
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Reads extra mode-specific values directly from engineStore.
 * Keeps CardHand decoupled from engine imports.
 */
function useModeExtras(gameMode: GameMode): {
  battleBudgetMax:   number;
  counterWindowOpen: boolean;
  rescueWindowOpen:  boolean;
} {
  // Dynamic import avoids circular deps with useCardHand
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const { useEngineStore } = require('../../../store/engineStore');

  const battleBudgetMax   = useEngineStore((s: any) => s.card?.battleBudgetMax   ?? 200);
  const counterWindowOpen = useEngineStore((s: any) => s.card?.counterWindowOpen  ?? false);
  const rescueWindowOpen  = useEngineStore((s: any) => s.card?.rescueWindowOpen   ?? false);

  return { battleBudgetMax, counterWindowOpen, rescueWindowOpen };
}