//Users/mervinlarry/workspaces/adam/Projects/adam/point_zero_one_master/pzo-web/src/features/run/components/CardSlot.tsx

// pzo-web/src/features/run/components/CardSlot.tsx
//
// ═══════════════════════════════════════════════════════════════════════════════
// POINT ZERO ONE — CardSlot
//
// Single card display unit — renders:
//   - Card art placeholder (background color by deck type)
//   - Card name + timing class badge
//   - Mode-overlay cost (cash or BB depending on mode)
//   - Effect summary + tag chips
//   - Forced card indicator (red pulsing border)
//   - LEGENDARY gold border treatment
//   - Hold state (grayed timer ring)
//   - Click / tap → card play dispatch
//
// RULES:
//   ✦ Pure display. Receives all data via props — no store reads.
//   ✦ All play / hold actions dispatched via callbacks from useCardHand.
//   ✦ DecisionTimerRing receives pre-computed DecisionWindowInfo.
//
// Density6 LLC · Point Zero One · Cards Engine · Confidential
// ═══════════════════════════════════════════════════════════════════════════════

import React, { useCallback } from 'react';
import {
  GameMode,
  TimingClass,
  BaseDeckType,
  ModeDeckType,
  CardRarity,
  CardTag,
  type CardInHand,
  type CardPlayRequest,
} from '../../../engines/cards/types';
import { DecisionTimerRing }     from './DecisionTimerRing';
import type { DecisionWindowInfo } from '../hooks/useDecisionWindow';
import { getCardCostLabel, getTrustModifierLabel, getDivergenceLabel } from '../hooks/useCardHand';

// ── DECK TYPE → COLOR MAP ─────────────────────────────────────────────────────

const DECK_TYPE_COLORS: Record<string, string> = {
  [BaseDeckType.OPPORTUNITY]:    '#1d4ed8',  // blue
  [BaseDeckType.IPA]:            '#15803d',  // green
  [BaseDeckType.FUBAR]:          '#7f1d1d',  // dark red
  [BaseDeckType.PRIVILEGED]:     '#6b21a8',  // purple
  [BaseDeckType.SO]:             '#b45309',  // amber
  [BaseDeckType.PHASE_BOUNDARY]: '#0f766e',  // teal
  [ModeDeckType.SABOTAGE]:       '#b91c1c',  // red
  [ModeDeckType.COUNTER]:        '#1e40af',  // navy
  [ModeDeckType.BLUFF]:          '#854d0e',  // brown
  [ModeDeckType.AID]:            '#065f46',  // emerald
  [ModeDeckType.RESCUE]:         '#0369a1',  // sky
  [ModeDeckType.TRUST]:          '#4338ca',  // indigo
  [ModeDeckType.DEFECTION]:      '#1f2937',  // near-black
  [ModeDeckType.GHOST]:          '#334155',  // slate
  [ModeDeckType.DISCIPLINE]:     '#374151',  // gray-700
};

function getDeckColor(card: CardInHand): string {
  return DECK_TYPE_COLORS[card.definition.deckType] ?? '#374151';
}

// ── TIMING CLASS BADGE ────────────────────────────────────────────────────────

const TIMING_BADGE_LABELS: Record<TimingClass, string> = {
  [TimingClass.IMMEDIATE]:            'IMM',
  [TimingClass.REACTIVE]:             'REACT',
  [TimingClass.STANDARD]:             'STD',
  [TimingClass.HOLD]:                 'HOLD',
  [TimingClass.COUNTER_WINDOW]:       'CTR',
  [TimingClass.RESCUE_WINDOW]:        'RSC',
  [TimingClass.PHASE_BOUNDARY]:       'PB',
  [TimingClass.FORCED]:               'FORCE',
  [TimingClass.LEGENDARY]:            'LEG',
  [TimingClass.BLUFF]:                'BLUFF',
  [TimingClass.DEFECTION_STEP]:       'DEF',
  [TimingClass.SOVEREIGNTY_DECISION]: 'SOV',
};

const TIMING_BADGE_COLORS: Record<TimingClass, string> = {
  [TimingClass.IMMEDIATE]:            '#16a34a',
  [TimingClass.REACTIVE]:             '#0284c7',
  [TimingClass.STANDARD]:             '#475569',
  [TimingClass.HOLD]:                 '#7c3aed',
  [TimingClass.COUNTER_WINDOW]:       '#1d4ed8',
  [TimingClass.RESCUE_WINDOW]:        '#0891b2',
  [TimingClass.PHASE_BOUNDARY]:       '#0f766e',
  [TimingClass.FORCED]:               '#dc2626',
  [TimingClass.LEGENDARY]:            '#d97706',
  [TimingClass.BLUFF]:                '#92400e',
  [TimingClass.DEFECTION_STEP]:       '#1f2937',
  [TimingClass.SOVEREIGNTY_DECISION]: '#7c3aed',
};

// ── COMPONENT ─────────────────────────────────────────────────────────────────

export interface CardSlotProps {
  card:            CardInHand;
  windowInfo:      DecisionWindowInfo;
  gameMode:        GameMode;
  isPlayable:      boolean;
  isSelected?:     boolean;
  battleBudget?:   number;
  trustMultiplier?:number;
  divergenceDelta?:number;

  onPlay:          (request: CardPlayRequest) => void;
  onHold?:         (instanceId: string) => void;
  onDragStart?:    (card: CardInHand) => void;
  onDragEnd?:      () => void;
}

export const CardSlot = React.memo(function CardSlot({
  card,
  windowInfo,
  gameMode,
  isPlayable,
  isSelected     = false,
  battleBudget   = 0,
  trustMultiplier= 1.0,
  divergenceDelta= 0,
  onPlay,
  onHold,
  onDragStart,
  onDragEnd,
}: CardSlotProps) {

  const handleClick = useCallback(() => {
    if (!isPlayable || card.isHeld) return;
    const request: CardPlayRequest = {
      instanceId: card.instanceId,
      choiceId:   'choice_default',
      timestamp:  Date.now(),
    };
    onPlay(request);
  }, [card, isPlayable, onPlay]);

  const handleHold = useCallback((e: React.MouseEvent) => {
    e.stopPropagation();
    if (gameMode !== GameMode.GO_ALONE || !onHold) return;
    onHold(card.instanceId);
  }, [card.instanceId, gameMode, onHold]);

  const handleDragStart = useCallback((e: React.DragEvent) => {
    if (!isPlayable) { e.preventDefault(); return; }
    e.dataTransfer.effectAllowed = 'move';
    onDragStart?.(card);
  }, [card, isPlayable, onDragStart]);

  const handleDragEnd = useCallback(() => {
    onDragEnd?.();
  }, [onDragEnd]);

  // ── Visual state flags ──────────────────────────────────────────────────────
  const isLegendary   = card.definition.rarity === CardRarity.LEGENDARY;
  const isForced      = card.isForced;
  const isHeld        = card.isHeld;
  const deckColor     = getDeckColor(card);
  const timingLabel   = TIMING_BADGE_LABELS[card.definition.timingClass];
  const timingColor   = TIMING_BADGE_COLORS[card.definition.timingClass];
  const costLabel     = getCardCostLabel(card, gameMode);
  const hasEffect     = card.definition.base_effect.magnitude > 0;

  // ── Border style ────────────────────────────────────────────────────────────
  let borderStyle = '2px solid rgba(255,255,255,0.12)';
  if (isLegendary) borderStyle = '2px solid #d97706';
  if (isForced)    borderStyle = '2px solid #dc2626';
  if (isSelected)  borderStyle = '2px solid #60a5fa';
  if (isHeld)      borderStyle = '2px solid #7c3aed';

  // ── Overlay signals ─────────────────────────────────────────────────────────
  const trustLabel     = gameMode === GameMode.TEAM_UP
    ? getTrustModifierLabel(trustMultiplier)
    : null;
  const divergenceLabel= gameMode === GameMode.CHASE_A_LEGEND && divergenceDelta !== 0
    ? getDivergenceLabel(Math.abs(divergenceDelta))
    : null;

  return (
    <div
      role="button"
      tabIndex={isPlayable && !isHeld ? 0 : -1}
      aria-label={`${card.definition.name} — ${costLabel}`}
      aria-disabled={!isPlayable}
      draggable={isPlayable && !isHeld}
      onClick={handleClick}
      onKeyDown={e => { if (e.key === 'Enter' || e.key === ' ') handleClick(); }}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      style={{
        position:      'relative',
        width:         112,
        height:        160,
        borderRadius:  12,
        border:        borderStyle,
        background:    `linear-gradient(160deg, ${deckColor}cc, ${deckColor}55)`,
        backdropFilter:'blur(8px)',
        cursor:        isPlayable && !isHeld ? 'pointer' : 'default',
        opacity:       isHeld ? 0.5 : (isPlayable ? 1.0 : 0.5),
        transition:    'transform 0.15s ease, opacity 0.2s ease, border 0.2s ease',
        userSelect:    'none',
        display:       'flex',
        flexDirection: 'column',
        padding:       '8px',
        boxSizing:     'border-box',
        transform:     isSelected ? 'translateY(-8px)' : 'none',
        boxShadow:     isLegendary
          ? '0 0 24px rgba(217,119,6,0.5), 0 4px 16px rgba(0,0,0,0.4)'
          : '0 4px 16px rgba(0,0,0,0.4)',
      }}
    >
      {/* Timing Class Badge */}
      <div style={{
        alignSelf:   'flex-start',
        background:  timingColor,
        color:       '#fff',
        fontSize:    9,
        fontWeight:  700,
        padding:     '2px 5px',
        borderRadius:4,
        letterSpacing:'0.05em',
        fontFamily:  'monospace',
      }}>
        {timingLabel}
      </div>

      {/* Card Name */}
      <div style={{
        marginTop:   6,
        fontSize:    11,
        fontWeight:  600,
        color:       '#f1f5f9',
        lineHeight:  1.3,
        overflow:    'hidden',
        display:     '-webkit-box',
        WebkitLineClamp: 2,
        WebkitBoxOrient: 'vertical',
      }}>
        {card.definition.name}
      </div>

      {/* Spacer */}
      <div style={{ flex: 1 }} />

      {/* Effect Summary */}
      {hasEffect && (
        <div style={{
          fontSize:   10,
          color:      'rgba(255,255,255,0.65)',
          marginBottom: 4,
          fontFamily: 'monospace',
        }}>
          +{(card.definition.base_effect.magnitude * 100).toFixed(0)}%
          {' '}
          {card.definition.base_effect.effectType
            .replace(/_/g, ' ')
            .toLowerCase()
            .slice(0, 14)}
        </div>
      )}

      {/* Tags */}
      <div style={{ display: 'flex', flexWrap: 'wrap', gap: 3, marginBottom: 4 }}>
        {card.definition.tags.slice(0, 3).map(tag => (
          <span key={tag} style={{
            fontSize:    8,
            background:  'rgba(255,255,255,0.12)',
            color:       'rgba(255,255,255,0.7)',
            padding:     '1px 4px',
            borderRadius:3,
            fontFamily:  'monospace',
          }}>
            {tag.slice(0, 8)}
          </span>
        ))}
      </div>

      {/* Cost Row */}
      <div style={{
        display:        'flex',
        justifyContent: 'space-between',
        alignItems:     'center',
      }}>
        <span style={{
          fontSize:   11,
          fontWeight: 700,
          color:      '#fcd34d',
          fontFamily: 'monospace',
        }}>
          {costLabel}
        </span>

        {/* Mode-specific signal */}
        {trustLabel && (
          <span style={{ fontSize: 9, color: '#a78bfa', fontFamily: 'monospace' }}>
            {trustLabel}
          </span>
        )}
        {divergenceLabel && (
          <span style={{ fontSize: 9, color: '#fb923c', fontFamily: 'monospace' }}>
            {divergenceLabel}
          </span>
        )}

        {/* Hold button (Empire only) */}
        {gameMode === GameMode.GO_ALONE && !isHeld && isPlayable && (
          <button
            onClick={handleHold}
            style={{
              background:  'rgba(124,58,237,0.3)',
              border:      '1px solid rgba(124,58,237,0.5)',
              borderRadius:4,
              color:       '#c4b5fd',
              fontSize:    8,
              padding:     '2px 5px',
              cursor:      'pointer',
              fontFamily:  'monospace',
            }}
          >
            HOLD
          </button>
        )}
      </div>

      {/* Forced indicator */}
      {isForced && (
        <div style={{
          position:   'absolute',
          top:        -6,
          right:      -6,
          background: '#dc2626',
          color:      '#fff',
          fontSize:   8,
          fontWeight: 700,
          padding:    '2px 5px',
          borderRadius:4,
          fontFamily: 'monospace',
          animation:  'pzo-ring-pulse 0.8s ease-in-out infinite',
        }}>
          FORCED
        </div>
      )}

      {/* Decision Timer Ring — overlaid on card */}
      <div style={{
        position:      'absolute',
        inset:         0,
        display:       'flex',
        alignItems:    'center',
        justifyContent:'center',
        pointerEvents: 'none',
        borderRadius:  12,
        overflow:      'hidden',
      }}>
        <DecisionTimerRing
          info={windowInfo}
          size={isHeld ? 60 : 100}
          showLabel={!isHeld}
        />
      </div>
    </div>
  );
});

export default CardSlot;