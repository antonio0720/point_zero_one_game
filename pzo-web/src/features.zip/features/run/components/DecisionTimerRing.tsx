//Users/mervinlarry/workspaces/adam/Projects/adam/point_zero_one_master/pzo-web/src/features/run/components/DecisionTimerRing.tsx

// pzo-web/src/features/run/components/DecisionTimerRing.tsx
//
// ═══════════════════════════════════════════════════════════════════════════════
// POINT ZERO ONE — DECISION TIMER RING (CANONICAL)
//
// SVG countdown ring wrapping each card slot.
// Driven exclusively by useDecisionWindow.
//
// BEHAVIORS:
//   • Color track: #22c55e (green) → #eab308 (yellow) → #f97316 (orange) → #ef4444 (red)
//   • Moving tip dot tracks arc head at 60fps via rAF in hook
//   • Pulse scale animation at progress >= 0.80 (< 20% remaining)
//   • Auto-resolve strobe: 4-burst red flash, CSS keyframe driven — no setInterval
//   • Ring disappears instantly on isResolved (card played)
//   • Ring disappears after flash completes on isExpired (auto-resolve)
//   • IMMEDIATE / LEGENDARY: ring never renders (hasWindow = false)
//   • Paused (Empire hold): ring freezes at current position, gold color
//
// Density6 LLC · Point Zero One · Cards Engine · Confidential
// ═══════════════════════════════════════════════════════════════════════════════

import React, { useEffect, useRef, useState, useCallback } from 'react';
import { useDecisionWindow, formatCountdown } from '../hooks/useDecisionWindow';

// ── GEOMETRY ──────────────────────────────────────────────────────────────────

const SIZE         = 88;                           // px — card is 80px + 4px padding each side
const STROKE       = 3.5;
const CX           = SIZE / 2;
const CY           = SIZE / 2;
const RADIUS       = CX - STROKE / 2 - 1;
const CIRCUMFERENCE = 2 * Math.PI * RADIUS;

// ── COLOR STOPS ───────────────────────────────────────────────────────────────

const C_GREEN  = '#22c55e';
const C_YELLOW = '#eab308';
const C_ORANGE = '#f97316';
const C_RED    = '#ef4444';
const C_GOLD   = '#f5c542';   // Empire hold

// ── THRESHOLDS ────────────────────────────────────────────────────────────────

const YELLOW_AT   = 0.50;   // progress > 0.50 → yellow zone
const ORANGE_AT   = 0.70;   // progress > 0.70 → orange zone
const RED_AT      = 0.80;   // progress > 0.80 → red zone, pulse starts
const FLASH_MS    = 1_400;  // total auto-resolve flash duration

// ── PROPS ─────────────────────────────────────────────────────────────────────

export interface DecisionTimerRingProps {
  cardInstanceId:    string;
  children:          React.ReactNode;
  className?:        string;
  /** Called after auto-resolve flash animation completes. */
  onAutoResolveEnd?: () => void;
  /** Render the countdown text inside the ring. Default: false. */
  showCountdown?:    boolean;
}

// ═══════════════════════════════════════════════════════════════════════════════
// COMPONENT
// ═══════════════════════════════════════════════════════════════════════════════

export const DecisionTimerRing: React.FC<DecisionTimerRingProps> = ({
  cardInstanceId,
  children,
  className = '',
  onAutoResolveEnd,
  showCountdown = false,
}) => {
  const info = useDecisionWindow(cardInstanceId);

  // ── Flash state (auto-resolve strobe) ────────────────────────────────────
  const [flashActive, setFlashActive]   = useState(false);
  const [flashDone, setFlashDone]       = useState(false);
  const flashTimerRef                   = useRef<ReturnType<typeof setTimeout> | null>(null);
  const prevExpiredRef                  = useRef(false);

  // Trigger flash exactly once when isExpired flips true
  useEffect(() => {
    if (info.isExpired && !prevExpiredRef.current && !flashDone) {
      prevExpiredRef.current = true;
      setFlashActive(true);

      flashTimerRef.current = setTimeout(() => {
        setFlashActive(false);
        setFlashDone(true);
        onAutoResolveEnd?.();
      }, FLASH_MS);
    }
    return () => {
      if (flashTimerRef.current) clearTimeout(flashTimerRef.current);
    };
  }, [info.isExpired]); // eslint-disable-line react-hooks/exhaustive-deps

  // ── Nothing to render ────────────────────────────────────────────────────
  // IMMEDIATE / LEGENDARY have no window
  if (!info.hasWindow) {
    return (
      <div className={`pzo-timer-ring-wrapper ${className}`}>
        {children}
      </div>
    );
  }

  // After flash completes, ring is gone
  if (flashDone) {
    return (
      <div className={`pzo-timer-ring-wrapper ${className}`}>
        {children}
      </div>
    );
  }

  // Card was played (resolved) — ring disappears instantly, no flash
  if (info.isResolved && !info.isExpired) {
    return (
      <div className={`pzo-timer-ring-wrapper ${className}`}>
        {children}
      </div>
    );
  }

  // ── Arc geometry ─────────────────────────────────────────────────────────
  const fraction        = info.fraction;  // 1.0 → 0.0
  const clamped         = Math.max(0, Math.min(1, fraction));
  const dashOffset      = CIRCUMFERENCE * (1 - clamped);

  // Tip dot position (arc starts at 12 o'clock = -π/2, sweeps clockwise)
  const arcAngle        = clamped * 2 * Math.PI - Math.PI / 2;
  const tipX            = CX + RADIUS * Math.cos(arcAngle);
  const tipY            = CY + RADIUS * Math.sin(arcAngle);

  // ── Color ─────────────────────────────────────────────────────────────────
  let ringColor: string;

  if (info.isPaused) {
    ringColor = C_GOLD;
  } else if (flashActive) {
    ringColor = C_RED;
  } else if (info.progress < YELLOW_AT) {
    // Green → Yellow (0 → 0.50)
    ringColor = lerpHex(C_GREEN, C_YELLOW, info.progress / YELLOW_AT);
  } else if (info.progress < ORANGE_AT) {
    // Yellow → Orange (0.50 → 0.70)
    ringColor = lerpHex(C_YELLOW, C_ORANGE, (info.progress - YELLOW_AT) / (ORANGE_AT - YELLOW_AT));
  } else {
    // Orange → Red (0.70 → 1.0)
    ringColor = lerpHex(C_ORANGE, C_RED, Math.min(1, (info.progress - ORANGE_AT) / (1 - ORANGE_AT)));
  }

  // ── Drop shadow intensity scales with urgency ─────────────────────────────
  const glowColor   = info.isRedZone || flashActive ? C_RED : ringColor;
  const glowRadius  = info.isRedZone ? 5 : info.isYellowZone ? 3 : 2;
  const glowOpacity = info.isRedZone ? 0.80 : 0.50;
  const dropShadow  = `drop-shadow(0 0 ${glowRadius}px rgba(${hexToRgbStr(glowColor)},${glowOpacity}))`;

  // ── CSS classes ───────────────────────────────────────────────────────────
  const wrapperClasses = [
    'pzo-timer-ring-wrapper',
    className,
    info.isRedZone  && !flashActive  ? 'pzo-timer-ring--pulsing' : '',
    flashActive                       ? 'pzo-timer-ring--flashing' : '',
    info.isPaused                     ? 'pzo-timer-ring--paused' : '',
  ].filter(Boolean).join(' ');

  return (
    <div
      className={wrapperClasses}
      style={{ position: 'relative', display: 'inline-flex', alignItems: 'center', justifyContent: 'center' }}
      role="timer"
      aria-label={`Decision timer: ${formatCountdown(info.remainingMs)} remaining`}
      aria-live="off"
    >
      {/* ── SVG Ring ─────────────────────────────────────────────────────── */}
      <svg
        className="pzo-timer-ring__svg"
        width={SIZE}
        height={SIZE}
        viewBox={`0 0 ${SIZE} ${SIZE}`}
        style={{
          position:      'absolute',
          top:           '50%',
          left:          '50%',
          transform:     'translate(-50%, -50%) rotate(-90deg)',
          pointerEvents: 'none',
          zIndex:        10,
          filter:        dropShadow,
        }}
        aria-hidden="true"
      >
        {/* Track ring */}
        <circle
          cx={CX} cy={CY} r={RADIUS}
          fill="none"
          stroke="rgba(255,255,255,0.08)"
          strokeWidth={STROKE}
        />

        {/* Progress arc */}
        <circle
          className="pzo-timer-ring__arc"
          cx={CX} cy={CY} r={RADIUS}
          fill="none"
          stroke={ringColor}
          strokeWidth={STROKE}
          strokeDasharray={CIRCUMFERENCE}
          strokeDashoffset={dashOffset}
          strokeLinecap="round"
          style={{
            transition: flashActive
              ? 'none'
              : 'stroke-dashoffset 0.07s linear, stroke 0.15s ease',
          }}
        />

        {/* Tip dot — tracks arc head */}
        {clamped > 0.015 && !info.isExpired && (
          <circle
            className="pzo-timer-ring__tip"
            cx={tipX}
            cy={tipY}
            r={STROKE * 0.85}
            fill={ringColor}
            style={{
              transition: flashActive ? 'none' : 'fill 0.15s ease',
            }}
          />
        )}
      </svg>

      {/* ── Flash overlay (red tint over card face) ───────────────────────── */}
      {flashActive && (
        <div
          className="pzo-timer-ring__flash-overlay"
          aria-hidden="true"
          style={{
            position:      'absolute',
            inset:         0,
            borderRadius:  10,
            background:    'rgba(239, 68, 68, 0.30)',
            pointerEvents: 'none',
            zIndex:        9,
          }}
        />
      )}

      {/* ── Countdown text (optional) ─────────────────────────────────────── */}
      {showCountdown && info.hasWindow && (
        <div
          className="pzo-timer-ring__countdown"
          aria-hidden="true"
          style={{
            position:   'absolute',
            bottom:     -16,
            left:       '50%',
            transform:  'translateX(-50%)',
            fontSize:   9,
            fontWeight: 700,
            color:      ringColor,
            whiteSpace: 'nowrap',
            zIndex:     11,
            transition: 'color 0.15s ease',
          }}
        >
          {formatCountdown(info.remainingMs)}
        </div>
      )}

      {/* ── Card children ────────────────────────────────────────────────── */}
      <div className="pzo-timer-ring__card-content" style={{ position: 'relative', zIndex: 1 }}>
        {children}
      </div>
    </div>
  );
};

export default DecisionTimerRing;

// ── COLOR HELPERS ─────────────────────────────────────────────────────────────

function hexToRgb(hex: string): [number, number, number] {
  const r = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
  return r ? [parseInt(r[1], 16), parseInt(r[2], 16), parseInt(r[3], 16)] : [255, 255, 255];
}

function hexToRgbStr(hex: string): string {
  const [r, g, b] = hexToRgb(hex);
  return `${r},${g},${b}`;
}

function lerpHex(a: string, b: string, t: number): string {
  const [ar, ag, ab] = hexToRgb(a);
  const [br, bg, bb] = hexToRgb(b);
  const tc = Math.max(0, Math.min(1, t));
  return `rgb(${Math.round(ar + (br - ar) * tc)},${Math.round(ag + (bg - ag) * tc)},${Math.round(ab + (bb - ab) * tc)})`;
}