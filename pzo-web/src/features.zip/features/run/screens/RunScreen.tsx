// pzo-web/src/features/run/screens/RunScreen.tsx
import React, { memo }       from 'react';
import { useDecisionWindow } from '../hooks/useDecisionWindow';
import { useRunState }       from '../../../hooks/useRunState';
import { MLProvider }        from '../../../ml/wiring/MLContext';
import CountdownRing         from './CountdownRing';
import HUD                   from './HUD';

const RunScreen = memo(() => {
  const { countdown }    = useDecisionWindow();
  const { state }        = useRunState();

  // MLProvider keyed on runId — resets all ML engines on each new run.
  // sessionRunCount drives sessionMomentum in PlayerModelEngine.
  return (
    <MLProvider
      key={state.runId}
      mode={state.mode}
      sessionRunCount={state.season?.runCount ?? 1}
    >
      <div className="run-screen">
        <CountdownRing value={countdown} />
        <HUD />
      </div>
    </MLProvider>
  );
});

export default RunScreen;